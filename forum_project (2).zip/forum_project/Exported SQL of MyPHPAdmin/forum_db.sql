-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2025 at 01:11 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `forum_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE `activities` (
  `id` int(11) NOT NULL,
  `activity_text` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_type` varchar(50) NOT NULL,
  `details` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `user_id`, `action_type`, `details`, `created_at`) VALUES
(1, 16, 'created_topic', 'Jobs', '2025-12-09 11:22:39'),
(2, 16, 'logout', 'User logged out', '2025-12-09 11:22:52'),
(3, 1, 'login', 'User logged in', '2025-12-09 11:23:11'),
(4, 1, 'logout', 'User logged out', '2025-12-09 12:48:15'),
(5, 21, 'created_topic', 'Studies', '2025-12-10 07:36:17'),
(6, 21, 'logout', 'User logged out', '2025-12-10 07:37:59'),
(7, 1, 'edited_topic', 'Web Programming', '2025-12-10 07:39:30'),
(8, 1, 'deleted_topic', 'Topic ID 6 deleted', '2025-12-10 07:39:42'),
(9, 1, 'logout', 'User logged out', '2025-12-11 00:21:13'),
(10, 24, 'login', 'User logged in', '2025-12-11 02:18:04'),
(11, 24, 'logout', 'User logged out', '2025-12-11 04:15:30'),
(12, 1, 'login', 'User logged in', '2025-12-11 04:15:38'),
(13, 1, 'logout', 'User logged out', '2025-12-11 09:10:37'),
(14, 24, 'login', 'User logged in', '2025-12-11 09:10:45'),
(15, 24, 'deleted_topic', 'Deleted Topic ID 2 (title: Software Engineering)', '2025-12-11 09:10:53'),
(16, 24, 'deleted_comment', 'Deleted Comment ID 8 on Topic ID 5', '2025-12-11 09:11:14'),
(17, 24, 'logout', 'User logged out', '2025-12-11 09:18:06'),
(18, 1, 'login', 'User logged in', '2025-12-11 09:18:13'),
(19, 1, 'logout', 'User logged out', '2025-12-11 09:19:06'),
(20, 24, 'login', 'User logged in', '2025-12-11 09:19:15'),
(21, 24, 'deleted_topic', 'Deleted Topic ID 3 (title: Software Engineering)', '2025-12-11 09:19:26'),
(22, 24, 'deleted_comment', 'Deleted Comment ID 6 on Topic ID 4', '2025-12-11 09:19:40'),
(23, 24, 'logout', 'User logged out', '2025-12-11 10:21:11'),
(24, 25, 'created_topic', 'Movies', '2025-12-11 10:21:57'),
(25, 25, 'logout', 'User logged out', '2025-12-11 10:22:11'),
(26, 25, 'login', 'User logged in', '2025-12-11 10:22:20'),
(27, 25, 'logout', 'User logged out', '2025-12-11 10:22:22'),
(28, 24, 'login', 'User logged in', '2025-12-11 10:22:32'),
(29, 25, 'suspend', 'User suspended by admin', '2025-12-11 10:29:48'),
(30, 24, 'logout', 'User logged out', '2025-12-11 10:30:00'),
(31, 25, 'blocked_login', 'Suspended user attempted to login', '2025-12-11 10:30:10'),
(32, 24, 'login', 'User logged in', '2025-12-11 10:31:31'),
(33, 24, 'logout', 'User logged out', '2025-12-11 10:32:07'),
(34, 26, 'created_topic', 'boom', '2025-12-11 10:32:33'),
(35, 26, 'logout', 'User logged out', '2025-12-11 10:32:39'),
(36, 24, 'login', 'User logged in', '2025-12-11 10:32:47'),
(37, 26, 'suspend', 'User suspended by admin', '2025-12-11 10:33:08'),
(38, 21, 'suspend', 'User suspended by admin', '2025-12-11 10:45:24'),
(39, 24, 'deleted_topic', 'Deleted Topic ID 11 (title: boom)', '2025-12-11 10:45:52'),
(40, 24, 'logout', 'User logged out', '2025-12-11 11:03:26'),
(41, 27, 'created_topic', 'ROnaldo', '2025-12-22 09:14:15'),
(42, 27, 'edited_topic', 'ROnaldo', '2025-12-22 09:14:29'),
(43, 27, 'deleted_topic', 'Deleted Topic ID 12 (title: ROnaldo)', '2025-12-22 09:15:05'),
(44, 27, 'logout', 'User logged out', '2025-12-22 09:15:57'),
(45, 28, 'logout', 'User logged out', '2025-12-22 09:16:30'),
(46, 28, 'login', 'User logged in', '2025-12-22 09:16:41'),
(47, 28, 'logout', 'User logged out', '2025-12-22 09:16:47'),
(48, 24, 'login', 'User logged in', '2025-12-22 09:19:29'),
(49, 24, 'deleted_topic', 'Deleted Topic ID 8 (title: Jobs)', '2025-12-22 09:19:49'),
(50, 24, 'logout', 'User logged out', '2025-12-22 09:31:52'),
(51, 29, 'created_topic', 'Software Engineering', '2025-12-23 09:00:05'),
(52, 29, 'edited_topic', 'Software Engineering Part 1', '2025-12-23 09:00:41'),
(53, 29, 'deleted_comment', 'Deleted Comment ID 20 on Topic ID 4', '2025-12-23 09:02:15'),
(54, 29, 'logout', 'User logged out', '2025-12-23 09:03:33'),
(55, 24, 'login', 'User logged in', '2025-12-23 09:03:58'),
(56, 24, 'deleted_comment', 'Deleted Comment ID 19 on Topic ID 13', '2025-12-23 09:04:24'),
(57, 29, 'suspend', 'User suspended by admin', '2025-12-23 09:05:02'),
(58, 24, 'logout', 'User logged out', '2025-12-23 09:05:29');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `comment_text` text NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `parent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `topic_id`, `comment_text`, `user_id`, `content`, `created_at`, `parent_id`) VALUES
(5, 4, 'Wow', 1, '', '2025-12-08 06:38:13', NULL),
(7, 5, 'Wow', 15, '', '2025-12-08 11:34:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comment_likes`
--

CREATE TABLE `comment_likes` (
  `id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`id`, `user_id`, `title`, `content`, `created_at`) VALUES
(4, 1, 'Software Engineering', 'I believe that Software Engineering is one of the most taken and completed course of 2025', '2025-12-08 02:36:21'),
(5, 15, 'Jesus', 'I am Jesus\r\n', '2025-12-08 11:34:25');

-- --------------------------------------------------------

--
-- Table structure for table `topic_likes`
--

CREATE TABLE `topic_likes` (
  `id` int(11) NOT NULL,
  `topic_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` tinyint(1) NOT NULL DEFAULT 1,
  `bio` text DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `suspended` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `bio`, `profile_pic`, `created_at`, `suspended`) VALUES
(1, 'Keshav Suresh', 'webprogramming@gamil.com', '$2y$10$3WdjAkHIAAwzhLRhrrhUZ.xOFIdQ99URPJ7Fv1whcuh3bQyqF9C6a', 1, 'I am a Student', '1_1765178489.png', '2025-12-08 01:11:16', 0),
(3, 'John', '', '$2y$10$fmtLLrqqoYJoxy66pHJRoOTsnyLcTWaBYdlt2iHKDbxcmBJmPNNy6', 0, NULL, NULL, '2025-12-08 10:34:35', 0),
(10, 'Job', 'job@gmail.com', '$2y$10$wwgRR414eZjXBGUpsArAKObjmGiavP/Wg5kHLPMd7QftaammrlwLm', 0, NULL, NULL, '2025-12-08 10:54:49', 0),
(12, 'asdaas', 'sdasaaszd@daas', '$2y$10$UeBhUctlAJsv5eJK9gXRIuqJAhAhYLrqJzrOA/w87nBcLqYcMgHMS', 0, NULL, NULL, '2025-12-08 11:04:25', 0),
(13, 'Jonny', 'jonny@gmail.com', '$2y$10$OVbecdkIf0GZt8iHkQq1B.Ku4uTidxymZGJyznrXXBV5khx1SteA.', 0, NULL, NULL, '2025-12-08 11:09:09', 0),
(14, 'joby', 'joby@gmail.com', '$2y$10$nZpuI5VZ3pUMS7IsatiVAemRTarCqHV9lC0XJkfXCvNUR0v9MViyu', 0, NULL, NULL, '2025-12-08 11:10:05', 0),
(15, 'jin', 'jin@gmail.com', '$2y$10$UvalQoYJY4Nq6sSkoTYXuuyk4JT80B2wjVUj72uxxkMMgG0mhb4nG', 0, 'Boo', '15_1765193647.jpg', '2025-12-08 11:33:36', 0),
(16, 'Jelly', 'jelly@gmail.com', '$2y$10$2f.avH0BpIv.Go4ZdPC9fOlSdZncQMd/C.khaCwnCQGHLTXyLUKaq', 0, '', NULL, '2025-12-09 04:47:22', 0),
(21, 'jonson', 'jonson@gmail.com', '$2y$10$ITZDdNhCuusJSj0XRu6mn.C3waV6Tsdrf3ItJYPjTNuhgvH.bsFm6', 0, 'sasd', NULL, '2025-12-10 07:34:56', 1),
(24, 'admin', 'admin@example.com', 'admin123', 1, NULL, NULL, '2025-12-11 01:33:23', 0),
(25, 'jimmy', 'jimmy@gail.com', '$2y$10$pj/89eUQZymnTmZj8sJM8eB9znq7zKnLAs0XqXi6Kt2ziEHVEJuRy', 0, NULL, NULL, '2025-12-11 10:21:41', 1),
(26, 'josh', 'josh@gmail.com', '$2y$10$jAq47BJ4LGS73LNB46IidOyaJzH/qXmf3VbwK3T0ICIDZU1d3Itfu', 0, NULL, NULL, '2025-12-11 10:32:24', 1),
(27, 'Keshav', 'keshav@gmail.com', '$2y$10$mgUPA2vXrbsvjEEthCFo2uAtrdb3ux1apH5BT3H51yCJ699lNSm3q', 0, 'sdbdbadkdiu', '27_1766394829.png', '2025-12-22 09:12:47', 0),
(28, 'Keshav1', 'dssazad@gmail.com', '$2y$10$OpZQGGgMhZb.umFx1CrMEu2Ult6EwlR/QisIDBx8dFHTYnHFXG9ny', 0, NULL, NULL, '2025-12-22 09:16:29', 0),
(29, 'ahmed', 'ahmed@gmail.com', '$2y$10$FJNrU96tpIw1JHCbA2RzHeUWh2vAECIqqr3bjiQ/5h4hhuJmu/m8K', 0, 'uyyu6f', '29_1766480573.png', '2025-12-23 08:59:30', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activities`
--
ALTER TABLE `activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_topic` (`topic_id`);

--
-- Indexes for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `comment_id` (`comment_id`,`user_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `topic_likes`
--
ALTER TABLE `topic_likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `topic_id` (`topic_id`,`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activities`
--
ALTER TABLE `activities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `comment_likes`
--
ALTER TABLE `comment_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `topic_likes`
--
ALTER TABLE `topic_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD CONSTRAINT `activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `fk_topic` FOREIGN KEY (`topic_id`) REFERENCES `topics` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
