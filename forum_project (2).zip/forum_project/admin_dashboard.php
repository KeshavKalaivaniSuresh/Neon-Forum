<?php
session_start();
include 'db_connect.php';

// Only allow admin
if(!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1){
    header("Location: index.php");
    exit;
}

// Fetch all topics
$topics_query = mysqli_query($conn, "SELECT * FROM topics ORDER BY created_at DESC");

// Fetch all comments
$comments_query = mysqli_query($conn, "SELECT * FROM comments ORDER BY created_at DESC");

// Fetch all users
$users_query = mysqli_query($conn, "SELECT * FROM users ORDER BY id ASC");

// Include header for navbar (logout will now show correctly)
include("includes/header.php");
?>

<div class="container container-main">
    <h1 class="neon-heading mb-4">Admin Dashboard</h1>

    <!-- ⭐ Neon filter/sort buttons -->
    <div class="d-flex gap-2 mb-4">
        <button class="btn btn-outline-info neon-btn" onclick="filterSection('topics')">Show Topics</button>
        <button class="btn btn-outline-info neon-btn" onclick="filterSection('comments')">Show Comments</button>
        <button class="btn btn-outline-info neon-btn" onclick="filterSection('users')">Show Users</button>
    </div>

    <!-- All Topics -->
    <div id="topics" class="section card-section">
        <h2 class="neon-subheading">All Topics</h2>
        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th>ID</th><th>Title</th><th>Author</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($topic = mysqli_fetch_assoc($topics_query)) { ?>
                <tr>
                    <td><?php echo $topic['id']; ?></td>
                    <td><?php echo htmlspecialchars($topic['title']); ?></td>
                    <td><?php echo htmlspecialchars($topic['author']); ?></td>
                    <td>
                        <a class="delete-btn neon-btn" href="admin_delete_topic.php?id=<?php echo $topic['id']; ?>" onclick="return confirm('Delete this topic?')">Delete</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- All Comments -->
    <div id="comments" class="section card-section" style="display:none;">
        <h2 class="neon-subheading">All Comments</h2>
        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th>ID</th><th>Topic ID</th><th>Author</th><th>Comment</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($comment = mysqli_fetch_assoc($comments_query)) { ?>
                <tr>
                    <td><?php echo $comment['id']; ?></td>
                    <td><?php echo $comment['topic_id']; ?></td>
                    <td><?php echo $comment['author']; ?></td>
                    <td><?php echo htmlspecialchars($comment['comment']); ?></td>
                    <td>
                        <a class="delete-btn neon-btn" href="admin_delete_comment.php?id=<?php echo $comment['id']; ?>" onclick="return confirm('Delete this comment?')">Delete</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- All Users -->
    <div id="users" class="section card-section" style="display:none;">
        <h2 class="neon-subheading">All Users</h2>
        <table class="table table-dark table-hover">
            <thead>
                <tr>
                    <th>ID</th><th>Username</th><th>Email</th><th>Admin</th><th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($user = mysqli_fetch_assoc($users_query)) { ?>
                <tr>
                    <td><?php echo $user['id']; ?></td>
                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo ($user['is_admin'] ? 'Yes' : 'No'); ?></td>
                    <td>
                        <?php if(!$user['is_admin']) { ?>
                        <a class="delete-btn neon-btn" href="admin_delete_user.php?id=<?php echo $user['id']; ?>" onclick="return confirm('Delete this user?')">Delete</a>
                        <?php } ?>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<style>
.neon-heading {
    color: #00e5ff;
    text-shadow: 0 0 8px #00e5ff, 0 0 16px #7c4dff;
}
.neon-subheading {
    color: #7c4dff;
    text-shadow: 0 0 5px #7c4dff, 0 0 10px #00e5ff;
}
.card-section {
    background: rgba(11,15,20,0.85);
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 0 15px #00e5ff33;
}
table th {
    background: linear-gradient(90deg,#7c4dff66,#00e5ff66);
    color: #00101a;
}
table tr:hover {
    background: rgba(124,77,255,0.1);
}
.delete-btn {
    color: #ff0080;
    font-weight: 600;
    text-decoration: none;
    transition: 0.2s;
}
.delete-btn:hover {
    text-shadow: 0 0 5px #ff0080,0 0 10px #ff00ff;
    color: #ff00ff;
}
/* Neon filter buttons */
.neon-btn {
    border: 1px solid #00e5ff;
    color: #00e5ff;
    background: transparent;
    border-radius: 8px;
    padding: 5px 12px;
    font-weight: 500;
    box-shadow: 0 0 5px #00e5ff66, 0 0 10px #7c4dff33;
    transition: 0.2s;
}
.neon-btn:hover {
    background: linear-gradient(90deg,#7c4dff,#00e5ff);
    color: #00101a;
    box-shadow: 0 0 10px #00e5ff,0 0 20px #7c4dff;
}
</style>

<script>
// Simple section filter
function filterSection(section) {
    document.getElementById('topics').style.display = 'none';
    document.getElementById('comments').style.display = 'none';
    document.getElementById('users').style.display = 'none';
    document.getElementById(section).style.display = 'block';
}
</script>


