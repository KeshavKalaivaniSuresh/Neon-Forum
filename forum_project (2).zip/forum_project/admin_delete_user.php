<?php
session_start();
include 'db_connection.php';

if(!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1){
    header("Location: index.php");
    exit;
}

if(isset($_GET['id'])){
    $id = intval($_GET['id']);
    mysqli_query($conn, "DELETE FROM users WHERE id=$id AND is_admin=0"); // never delete admin
}

header("Location: admin_dashboard.php");
exit;
?>
