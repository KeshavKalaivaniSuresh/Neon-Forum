
<?php
include "db_connect.php";
include "includes/header.php";

if (!isset($_SESSION['user_id'])) {
    echo "<div class='alert alert-warning'>You must be logged in to create a topic.</div>";
    include("footer.php");
    exit;
}

$message = "";

if (isset($_POST['create'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);
    $user_id = $_SESSION['user_id'];

    $query = "INSERT INTO topics (user_id, title, content) 
              VALUES ('$user_id', '$title', '$content')";

    if (mysqli_query($conn, $query)) {
        include "log_activity.php";
        logActivity($conn, $user_id, "created_topic", $title);
        $message = "<div class='alert alert-success'>Topic created successfully!</div>";
    } else {
        $message = "<div class='alert alert-danger'>Error: " . mysqli_error($conn) . "</div>";
    }
}
?>

<h2 class="fw-bold neon-heading mb-4">Create New Topic</h2>

<?php echo $message; ?>

<div class="card card-post p-4 shadow-sm" style="border-radius: 12px; max-width: 700px;">
    <form method="POST">
        <div class="mb-3">
            <label class="form-label fw-semibold">Topic Title</label>
            <input type="text" name="title" class="form-control neon-input" required>
        </div>

        <div class="mb-3">
            <label class="form-label fw-semibold">Discussion Content</label>
            <textarea name="content" class="form-control neon-input" rows="6" required></textarea>
        </div>

        <button type="submit" name="create" class="btn btn-primary neon-btn">
            Post Topic
        </button>
    </form>
</div>

<?php include("footer.php"); ?>

<style>
.neon-heading { color: #00ffff; text-shadow: 0 0 5px #00ffff, 0 0 10px #7c4dff, 0 0 15px #00ffff; }
.card-post { background-color: #1b1f2a; border: 1px solid #00ffff55; box-shadow: 0 0 8px #00ffff33; }
.card-post:hover { box-shadow: 0 0 15px #00ffff55, 0 0 25px #7c4dff33; transition: 0.3s; }
textarea.neon-input, input.neon-input { background-color: #1b1f2a; color: #f0f4ff; border: 1px solid #00ffff; box-shadow: 0 0 8px #00ffff33; transition: 0.3s; border-radius: 8px; }
textarea.neon-input:focus, input.neon-input:focus { outline:none; border-color:#00ffff; box-shadow:0 0 12px #00ffff55; }
button.neon-btn { background-color:#00ffff; color:#000; border:none; box-shadow:0 0 8px #00ffff33; transition:0.3s; }
button.neon-btn:hover { box-shadow:0 0 15px #00ffff55; }
body { font-family: 'Poppins', sans-serif; }
</style>
