<?php
session_start();
include("db_connect.php");
include("log_activity.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$comment_id = intval($_GET['id']);
$topic_id = intval($_GET['topic_id'] ?? 0);

// Fetch comment owner & content
$sql = "SELECT user_id, comment_text FROM comments WHERE id = $comment_id";
$result = mysqli_query($conn, $sql);
if (!$result || mysqli_num_rows($result) == 0) {
    header("Location: view_topic.php?id=" . max(0,$topic_id));
    exit;
}
$row = mysqli_fetch_assoc($result);
$owner_id = intval($row['user_id']);
$comment_text = $row['comment_text'];

$is_owner = ($_SESSION['user_id'] === $owner_id);
$is_admin = (isset($_SESSION['is_admin']) && $_SESSION['is_admin']);

if (!$is_owner && !$is_admin) {
    echo "<div class='neon-alert'>Unauthorized to delete this comment.</div>";
    exit;
}

// Delete
mysqli_query($conn, "DELETE FROM comments WHERE id = $comment_id");

// Log
logActivity($conn, $_SESSION['user_id'], "deleted_comment", "Deleted Comment ID $comment_id on Topic ID $topic_id");

header("Location: view_topic.php?id=" . max(0,$topic_id));
exit;
?>
