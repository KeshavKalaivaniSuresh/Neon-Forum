<?php
session_start();
include("db_connect.php");
include("log_activity.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$topic_id = intval($_GET['id']);

// Fetch topic owner
$sql = "SELECT user_id, title FROM topics WHERE id = $topic_id";
$result = mysqli_query($conn, $sql);
if (!$result || mysqli_num_rows($result) == 0) {
    header("Location: index.php");
    exit;
}
$row = mysqli_fetch_assoc($result);
$owner_id = intval($row['user_id']);
$title = $row['title'];

// Allow deletion if owner or admin
$is_owner = ($_SESSION['user_id'] === $owner_id);
$is_admin = (isset($_SESSION['is_admin']) && $_SESSION['is_admin']);

if (!$is_owner && !$is_admin) {
    echo "<div class='neon-alert'>Unauthorized.</div>";
    exit;
}

// Delete topic + its comments
mysqli_query($conn, "DELETE FROM comments WHERE topic_id=$topic_id");
mysqli_query($conn, "DELETE FROM topics WHERE id=$topic_id");

// Log delete (whoever performed it)
logActivity($conn, $_SESSION['user_id'], "deleted_topic", "Deleted Topic ID $topic_id (title: " . mysqli_real_escape_string($conn, $title) . ")");

header("Location: index.php");
exit;
?>
