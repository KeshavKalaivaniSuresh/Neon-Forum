<?php
include "includes/header.php";
include "db_connect.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$uid = (int)$_SESSION['user_id'];
$errors = [];
$success = "";

// fetch existing
$stmt = mysqli_prepare($conn, "SELECT username, email, bio, profile_pic FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $uid);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $username, $email, $bio, $profile_pic);
mysqli_stmt_fetch($stmt);
mysqli_stmt_close($stmt);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // basic validation
    $new_username = trim($_POST['username'] ?? '');
    $new_email = trim($_POST['email'] ?? '');
    $new_bio = trim($_POST['bio'] ?? '');

    if ($new_username === '') $errors[] = "Username cannot be empty.";
    if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email.";

    // handle file upload if provided
    if (!empty($_FILES['profile_pic']['name'])) {
        $file = $_FILES['profile_pic'];
        $allowed = ['image/jpeg','image/png','image/webp'];
        if (!in_array($file['type'], $allowed)) {
            $errors[] = "Only JPG, PNG, and WEBP images allowed.";
        } elseif ($file['size'] > 2 * 1024 * 1024) {
            $errors[] = "File is too large (max 2MB).";
        } else {
            // generate safe filename
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = $uid . "_" . time() . "." . $ext;
            $target = __DIR__ . "/uploads/" . $filename;

            if (!move_uploaded_file($file['tmp_name'], $target)) {
                $errors[] = "Failed to upload file.";
            } else {
                // if old pic exists remove it
                if ($profile_pic && file_exists(__DIR__ . "/uploads/" . $profile_pic)) {
                    @unlink(__DIR__ . "/uploads/" . $profile_pic);
                }
                $profile_pic = $filename;
            }
        }
    }

    if (empty($errors)) {
        // update DB
        $upd = mysqli_prepare($conn, "UPDATE users SET username = ?, email = ?, bio = ?, profile_pic = ? WHERE id = ?");
        mysqli_stmt_bind_param($upd, "ssssi", $new_username, $new_email, $new_bio, $profile_pic, $uid);
        if (mysqli_stmt_execute($upd)) {
            $success = "Profile updated.";
            // update session username display
            $_SESSION['username'] = $new_username;
            // refresh local variables
            $username = $new_username; $email = $new_email; $bio = $new_bio;
        } else {
            $errors[] = "Database update failed.";
        }
        mysqli_stmt_close($upd);
    }
}
?>

<div class="card p-4" style="max-width:720px;">
  <h3>Edit Profile</h3>

  <?php if ($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
  <?php endif; ?>

  <?php if (!empty($errors)): ?>
    <div class="alert alert-danger">
      <?php foreach($errors as $e) echo "<div>" . htmlspecialchars($e) . "</div>"; ?>
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">
    <div class="mb-3">
      <label class="form-label">Username</label>
      <input name="username" class="form-control" value="<?php echo htmlspecialchars($username); ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Email</label>
      <input name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Bio</label>
      <textarea name="bio" class="form-control" rows="4"><?php echo htmlspecialchars($bio); ?></textarea>
    </div>

    <div class="mb-3">
      <label class="form-label">Profile picture (JPG, PNG, WEBP) — max 2MB</label>
      <input type="file" name="profile_pic" accept="image/*" class="form-control">
      <?php if ($profile_pic): ?>
        <div class="mt-2 small-muted">Current: <img src="uploads/<?php echo htmlspecialchars($profile_pic); ?>" style="height:45px;border-radius:6px;object-fit:cover;"></div>
      <?php endif; ?>
    </div>

    <button class="btn btn-primary">Save Changes</button>
  </form>
</div>

<?php include "footer.php"; ?>
