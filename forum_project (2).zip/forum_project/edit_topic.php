<?php
ob_start();
session_start();
include("db_connect.php");
include("includes/header.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$topic_id = intval($_GET['id']);

// Fetch topic
$sql = "SELECT * FROM topics WHERE id = $topic_id";
$result = mysqli_query($conn, $sql);
$topic = mysqli_fetch_assoc($result);

// Prevent editing another user's topic
if ($topic['user_id'] != $_SESSION['user_id']) {
    echo "<div class='alert alert-danger'>Unauthorized access.</div>";
    include("footer.php");
    exit;
}

$message = "";

if (isset($_POST['update'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $content = mysqli_real_escape_string($conn, $_POST['content']);

    $update_sql = "UPDATE topics SET title='$title', content='$content' WHERE id=$topic_id AND user_id=".$_SESSION['user_id'];

    if (mysqli_query($conn, $update_sql)) {
        include "log_activity.php";
        logActivity($conn, $_SESSION['user_id'], "edited_topic", $title);
        header("Location: view_topic.php?id=$topic_id");
        exit;
    } else {
        $message = "<div class='alert alert-danger'>Error updating topic.</div>";
    }
}
?>

<h2 class="fw-bold neon-heading">Edit Topic</h2>

<?php echo $message; ?>

<div class="card card-post p-4 shadow-sm" style="max-width:700px;">
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Topic Title</label>
            <input type="text" name="title" class="form-control neon-input" value="<?php echo htmlspecialchars($topic['title']); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Content</label>
            <textarea name="content" class="form-control neon-input" rows="6" required><?php echo htmlspecialchars($topic['content']); ?></textarea>
        </div>

        <button type="submit" name="update" class="btn btn-primary neon-btn">Save Changes</button>
    </form>
</div>

<?php include("footer.php"); ?>
