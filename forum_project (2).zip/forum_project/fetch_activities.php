<?php
include 'db_connect.php';

$result = mysqli_query($conn, "
    SELECT al.*, u.username 
    FROM activity_log al
    LEFT JOIN users u ON al.user_id = u.id
    ORDER BY al.id DESC 
    LIMIT 15
");

if (mysqli_num_rows($result) == 0) {
    echo "<p>No recent activity yet.</p>";
    exit;
}

while ($row = mysqli_fetch_assoc($result)) {
    echo "<div class='activity-item' style='margin-bottom:10px;'>";
    
    echo "<b style='color:#0ff;'>" . htmlspecialchars($row['username'] ?? 'Unknown User') . "</b> ";
    echo htmlspecialchars($row['action_type']) . ": ";
    echo htmlspecialchars($row['details']);

    echo "<br><small style='color:#7cf;'>"
        . date("F j, Y g:i A", strtotime($row['created_at']))
        . "</small>";

    echo "</div><hr style='border-color:#00ffff33;'>";
}
?>

