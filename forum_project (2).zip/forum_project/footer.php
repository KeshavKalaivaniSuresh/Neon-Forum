</div>

<!-- Bootstrap JS (required for dropdowns, modals, etc.) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

<script>
function loadActivity() {
    fetch("load_activity.php")
        .then(response => response.text())
        .then(data => {
            document.getElementById("activity_feed").innerHTML = data;
        });
}

loadActivity();
setInterval(loadActivity, 10000); // every 10 seconds
</script>

</html>

