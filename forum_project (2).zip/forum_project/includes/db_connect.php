
<?php
$host = "localhost";
$user = "root";  // default XAMPP username
$pass = "";       // default XAMPP password is empty
$dbname = "forum_db";

$conn = mysqli_connect($host, $user, $pass, $dbname);

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
