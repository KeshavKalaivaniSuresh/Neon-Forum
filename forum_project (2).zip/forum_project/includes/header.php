<?php
// Guarded session start — avoid "session already active" notices
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Neon Forum</title>

  <!-- Bootstrap -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">

  <!-- Neon modern custom styles -->
  <style>
    :root{
      --bg: #0b0f14;
      --panel: #071023;
      --neon: #7c4dff;
      --neon-2: #00e5ff;
      --muted: #9aa4b2;
    }
    html,body { background: linear-gradient(180deg, var(--bg), #081021 60%); color: #e6eef8; height:100%; }
    .navbar { background: linear-gradient(90deg, rgba(124,77,255,0.15), rgba(0,229,255,0.07)); border-bottom: 1px solid rgba(124,77,255,0.08); }
    .navbar-brand{ font-weight:800; letter-spacing: 0.6px; color: #eaf2ff !important; text-shadow: 0 2px 8px rgba(124,77,255,0.06); }
    .neon-btn { box-shadow: 0 4px 18px rgba(124,77,255,0.12); border-radius: 10px; }
    .container-main { padding-top: 18px; padding-bottom: 48px; }
    .card { background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(0,0,0,0.08)); border: 1px solid rgba(124,77,255,0.06); }
    .topic-title a { color:#e6eef8; transition: color .12s ease; }
    .topic-title a:hover{ color: var(--neon-2); text-decoration:none; }
    .badge-neon { background: linear-gradient(90deg,var(--neon),var(--neon-2)); color: #00101a; font-weight:700; }
    /* profile pic in navbar */
    .nav-profile { display:flex; align-items:center; gap:8px; }
    .nav-profile img { width:36px; height:36px; object-fit:cover; border-radius:8px; border: 2px solid rgba(255,255,255,0.06); box-shadow: 0 6px 18px rgba(0,0,0,0.6); }
    .profile-ghost { width:36px; height:36px; border-radius:8px; background: linear-gradient(90deg,var(--neon),var(--neon-2)); display:inline-block; }
    .small-muted { color: var(--muted); font-size:0.9rem; }
    textarea, input.form-control { background: rgba(255,255,255,0.02); color: #eaf2ff; border: 1px solid rgba(255,255,255,0.03); }
    label { color: #dfe9ff; }
    a { color: #bcd8ff; }
    footer { color: var(--muted); padding: 18px 0; text-align:center; }

    /* FIX: Make all normal text brighter and easier to read */
    .card, .card p, .card li, .card div, .card span, .card small, .card a {
        color: #f2f6ff !important;
    }

    /* FIX: Make post titles bright and more readable */
    .topic-title a {
        color: #ffffff !important;
        font-weight: 600;
    }

    /* FIX: Improve contrast on post metadata */
    .small-muted {
        color: #c9d6ff !important;
    }

    /* FIX: Make comment text bright */
    .comment-text, .comment {
        color: #f0f4ff !important;
    }
    /* Make post metadata brighter */
    .post-meta {
        color: #f0f4ff !important; /* bright white-ish */
        font-size: 0.9rem;         /* slightly smaller than title */
        margin-bottom: 10px;
    }

    /* Neon alert styling (global) */
    .neon-alert {
        background-color: #1b1f2a;
        color: #ff00ff;
        border: 1px solid #ff00ff;
        box-shadow: 0 0 8px #ff00ff77, 0 0 15px #ff00ff44;
        padding: 12px 15px;
        border-radius: 8px;
        font-weight: 500;
        margin-bottom: 15px;
        text-align: center;
    }
    .neon-alert-glow {
        animation: neonFlash 1.5s infinite alternate;
    }
    @keyframes neonFlash {
        0% { box-shadow: 0 0 5px #ff00ff55, 0 0 10px #ff00ff33; }
        100% { box-shadow: 0 0 15px #ff00ffaa, 0 0 25px #ff00ff77; }
    }

  </style>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
/* Apply font to the entire page */
body, input, textarea, button {
    font-family: 'Poppins', sans-serif;
}
/* Neon glow for headings */
.neon-heading {
    color: var(--neon-2);
    text-shadow: 0 0 5px var(--neon-2), 0 0 10px var(--neon-2), 0 0 15px var(--neon);
}
.neon-heading:hover {
    text-shadow: 0 0 10px var(--neon-2), 0 0 20px var(--neon-2), 0 0 30px var(--neon);
    transition: 0.3s;
}
/* Neon glow for post and comment cards */
.card-post, .comment-card {
    border: 1px solid var(--neon-2);
    box-shadow: 0 0 8px rgba(0, 229, 255, 0.3), 0 0 15px rgba(124, 77, 255, 0.15);
    transition: 0.3s;
}
.card-post:hover, .comment-card:hover {
    box-shadow: 0 0 15px rgba(0, 229, 255, 0.5), 0 0 25px rgba(124, 77, 255, 0.3);
}
/* Neon input glow for comment textarea */
.neon-input {
    background: rgba(0,0,0,0.15);
    border: 1px solid var(--neon-2);
    color: #e6eef8;
    box-shadow: 0 0 8px rgba(0,229,255,0.3), 0 0 12px rgba(124,77,255,0.2);
    transition: 0.3s;
}
.neon-input:focus {
    outline: none;
    border-color: var(--neon);
    box-shadow: 0 0 12px rgba(0,229,255,0.6), 0 0 18px rgba(124,77,255,0.4);
}
</style>

</head>
<body>

<nav class="navbar navbar-expand-lg mb-3">
  <div class="container">
    <a class="navbar-brand" href="index.php">NEON Forum</a>

    <div class="d-flex align-items-center ms-auto gap-2">
      <?php if(isset($_SESSION['user_id'])): ?>
        <?php
          // try to get small info for navbar (now also pull suspended flag)
          include_once __DIR__ . '/../db_connect.php';
          $uid = (int)($_SESSION['user_id'] ?? 0);
          $navpic = null;
          $is_suspended = 0;
          if ($uid) {
            $stmt = mysqli_prepare($conn, "SELECT username, profile_pic, suspended FROM users WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "i", $uid);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $nav_username, $nav_profile_pic, $nav_suspended);
            if (mysqli_stmt_fetch($stmt)) {
              $navpic = $nav_profile_pic;
              $is_suspended = intval($nav_suspended);
            }
            mysqli_stmt_close($stmt);
          }
          $avatar = ($navpic && file_exists(__DIR__ . "/../uploads/" . $navpic)) ? "uploads/" . $navpic : null;
        ?>
        <div class="nav-profile">
          <a href="profile.php?id=<?php echo $uid; ?>" class="d-flex align-items-center text-decoration-none">
            <?php if ($avatar): ?>
              <img src="<?php echo htmlspecialchars($avatar); ?>" alt="avatar">
            <?php else: ?>
              <span class="profile-ghost"></span>
            <?php endif; ?>
            <span class="ms-2 small-muted"><?php echo htmlspecialchars($_SESSION['username'] ?? 'You'); ?></span>
          </a>
        </div>

        <?php if ($is_suspended): ?>
            <!-- Suspended users cannot create topics; Logout still available -->
            <button class="btn btn-outline-secondary btn-sm neon-btn ms-2" disabled title="Your account has been suspended">Suspended</button>
            <a class="btn btn-danger btn-sm neon-btn ms-2" href="logout.php">Logout</a>
        <?php else: ?>
            <a class="btn btn-outline-light btn-sm neon-btn ms-2" href="create_topic.php">Create Topic</a>
            <a class="btn btn-danger btn-sm neon-btn ms-2" href="logout.php">Logout</a>
        <?php endif; ?>

      <?php else: ?>
        <a class="btn btn-light btn-sm neon-btn" href="login.php">Login</a>
        <a class="btn btn-success btn-sm neon-btn ms-2" href="register.php">Register</a>
      <?php endif; ?>
    </div>
  </div>
</nav>

<div class="container container-main">


