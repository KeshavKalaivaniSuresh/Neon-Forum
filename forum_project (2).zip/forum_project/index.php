<?php include("includes/header.php"); ?>
<?php include("db_connect.php"); ?>

<h2 class="fw-bold neon-heading mb-4">Latest Discussions</h2>

<!-- ⭐ NEW: Activity Feed Positioned on the Right Side -->
<div class="activity-feed">
    <h3>Recent Activities</h3>
    <div id="activityList">Loading...</div>
</div>

<?php
$result = mysqli_query($conn, "
    SELECT topics.*, users.username 
    FROM topics 
    JOIN users ON topics.user_id = users.id 
    ORDER BY topics.id DESC 
    LIMIT 10
");

while($row = mysqli_fetch_assoc($result)):
?>
    <div class="card card-post mb-3 shadow-sm" style="border-radius: 12px;">
        <div class="card-body d-flex justify-content-between align-items-start">
            <div style="flex:1;">
                <h4 class="topic-title mb-2">
                    <a href="view_topic.php?id=<?php echo $row['id']; ?>" class="text-decoration-none neon-link">
                        <?php echo htmlspecialchars($row['title']); ?>
                    </a>
                </h4>
                <p class="post-meta small mb-0">
                    Posted by 
                    <b>
                        <a href="profile.php?id=<?php echo intval($row['user_id']); ?>" class="text-decoration-none neon-link">
                            <?php echo htmlspecialchars($row['username']); ?>
                        </a>
                    </b>
                    • <?php echo date("F j, Y g:i A", strtotime($row['created_at'])); ?>
                </p>
            </div>

            <div class="ms-3" style="min-width:80px; text-align:right;">
                <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $row['user_id']): ?>
                    <a class="btn btn-sm btn-warning mb-1" href="edit_topic.php?id=<?php echo $row['id']; ?>">Edit</a><br>
                <?php endif; ?>

                <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                    <!-- Admin delete button -->
                    <a class="btn btn-sm btn-danger" href="delete_topic.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Admin: Delete this topic?');">Delete</a>
                <?php else: ?>
                    <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $row['user_id']): ?>
                        <!-- Owner delete (keeps same handler, will succeed) -->
                        <a class="btn btn-sm btn-danger" href="delete_topic.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Delete this topic?');">Delete</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php endwhile; ?>

<?php include("footer.php"); ?>

<!-- ⭐ NEW CSS (Placed safely at the bottom — keeps your styling untouched) -->
<style>
.neon-heading { color: #00ffff; text-shadow: 0 0 5px #00ffff, 0 0 10px #7c4dff, 0 0 15px #00ffff; }
.neon-link { color: #f0f4ff; text-shadow: 0 0 5px #00ffff; }
.neon-link:hover { color: #00ffff; text-shadow: 0 0 10px #00ffff, 0 0 15px #7c4dff; }
.card-post { background-color: #1b1f2a; border: 1px solid #00ffff55; box-shadow: 0 0 8px #00ffff33; }
.card-post:hover { box-shadow: 0 0 15px #00ffff55, 0 0 25px #7c4dff33; transition: 0.3s; }
body { font-family: 'Poppins', sans-serif; }

/* ⭐ NEW: Activity feed neon box */
.activity-feed {
    position: fixed;
    right: 20px;
    top: 120px;
    width: 300px;
    max-height: 70vh;
    overflow-y: auto;
    padding: 15px;
    border: 2px solid #0ff;
    box-shadow: 0 0 10px #0ff, 0 0 20px #0ff;
    color: white;
    background: rgba(0, 0, 0, 0.75);
    border-radius: 10px;
    z-index: 999;
}

.activity-feed h3 {
    text-align: center;
    color: #0ff;
    margin-bottom: 10px;
}

.activity-item {
    padding: 8px;
    margin-bottom: 10px;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 6px;
    font-size: 14px;
}
/* Make room on the right for the activity feed */
.container-main,
body > .container,
body > .container-fluid {
    padding-right: 360px !important; /* Activity feed width 300px + safe spacing */
}

</style>

<!-- ⭐ NEW JS — Auto-updates activities every 5 seconds -->
<script>
function loadActivities() {
    fetch('fetch_activities.php')
        .then(response => response.text())
        .then(data => {
            document.getElementById('activityList').innerHTML = data;
        });
}

loadActivities(); // Load immediately
setInterval(loadActivities, 5000); // Refresh every 5 sec
</script>



