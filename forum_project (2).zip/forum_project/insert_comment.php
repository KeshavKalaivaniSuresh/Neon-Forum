<?php
session_start();
include "db_connect.php";
include "log_activity.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$topic_id = intval($_POST['topic_id']);
$comment = mysqli_real_escape_string($conn, $_POST['comment']);
$user_id = $_SESSION['user_id'];

$sql = "INSERT INTO comments (topic_id, user_id, content)
        VALUES ($topic_id, $user_id, '$comment')";

if (mysqli_query($conn, $sql)) {
    logActivity($conn, $user_id, "commented", "Commented on Topic ID $topic_id");
}

header("Location: view_topic.php?id=$topic_id");
exit;
?>