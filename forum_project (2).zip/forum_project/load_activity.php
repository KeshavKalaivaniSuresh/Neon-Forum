<?php
include "db_connect.php";

$sql = "SELECT activity_log.*, users.username 
        FROM activity_log 
        JOIN users ON activity_log.user_id = users.id
        ORDER BY activity_log.created_at DESC
        LIMIT 10";

$result = mysqli_query($conn, $sql);

while ($row = mysqli_fetch_assoc($result)) {
    $time = date("F j, Y g:i A", strtotime($row['created_at']));
    echo "<p><b>{$row['username']}</b> {$row['action_type']} — <i>{$row['details']}</i><br>
          <small>$time</small></p><hr>";
}
?>
