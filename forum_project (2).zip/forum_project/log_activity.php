<?php
function logActivity($conn, $user_id, $action_type, $details) {
    if (!$conn) return; // Prevents crashes if DB fails

    $user_id = intval($user_id);
    $action_type = mysqli_real_escape_string($conn, $action_type);
    $details = mysqli_real_escape_string($conn, $details);

    $sql = "INSERT INTO activity_log (user_id, action_type, details)
            VALUES ('$user_id', '$action_type', '$details')";
    
    mysqli_query($conn, $sql);
}
?>
