<?php
include("db_connect.php");
include("log_activity.php"); // correct placement (top of file)

// Ensure session started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$message = "";

// Handle login BEFORE any HTML output
if (isset($_POST['login'])) {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $message = "<div class='neon-alert neon-alert-glow'>Please enter username and password.</div>";
    } else {

        // Prepared statement to fetch user (now also fetch suspended flag)
        $stmt = mysqli_prepare($conn, "SELECT id, username, password, suspended FROM users WHERE username = ? LIMIT 1");
        mysqli_stmt_bind_param($stmt, "s", $username);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($result && mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);
            $login_success = false;

            // If account suspended -> block login immediately
            if (isset($row['suspended']) && intval($row['suspended']) === 1) {
                // Log the blocked login attempt
                logActivity($conn, $row['id'], "blocked_login", "Suspended user attempted to login");
                $message = "<div class='neon-alert neon-alert-glow'>Your account has been suspended by the admin.</div>";
                mysqli_stmt_close($stmt);
            } else {
                // ---- START: Admin plain-text password logic ----
                if ($row['username'] === 'admin') {
                    if ($password === $row['password']) {
                        $login_success = true;
                    }
                } else {
                    if (password_verify($password, $row['password'])) {
                        $login_success = true;
                    }
                }
                // ---- END ----

                if ($login_success) {

                    // Log the login BEFORE redirect
                    logActivity($conn, $row['id'], "login", "User logged in");

                    // Set session variables
                    $_SESSION['user_id'] = $row['id'];
                    $_SESSION['username'] = $row['username'];

                    // NEW ADMIN FLAG (no redirect)
                    $_SESSION['is_admin'] = ($row['username'] === 'admin');

                    header("Location: index.php");
                    exit;

                } else {
                    $message = "<div class='neon-alert neon-alert-glow'>Username not found or Wrong Password!</div>";
                }

                mysqli_stmt_close($stmt);
            }

        } else {
            $message = "<div class='neon-alert neon-alert-glow'>Username not found or Wrong Password!</div>";
            if ($stmt) mysqli_stmt_close($stmt);
        }
    }
}

// Include header AFTER login logic
include("includes/header.php");
?>

<div class="register-container d-flex justify-content-center align-items-start">
    <div class="card p-4 shadow-sm" style="border-radius: 12px; max-width: 400px; margin-top: 80px;">
        <h2 class="fw-bold neon-heading text-center mb-4">Login</h2>

        <?php echo $message; ?>

        <form method="POST" class="neon-form">
            <div class="mb-3">
                <label class="form-label fw-semibold">Enter Username</label>
                <input type="text" name="username" class="form-control" placeholder="Username" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Enter Password</label>
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>

            <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
        </form>
    </div>
</div>

<?php include("footer.php"); ?>









