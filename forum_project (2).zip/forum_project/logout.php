
<?php
session_start();
include "db_connect.php";
include "log_activity.php";

if (isset($_SESSION['user_id'])) {
    logActivity($conn, $_SESSION['user_id'], "logout", "User logged out");
}

session_unset();
session_destroy();

header("Location: index.php");
exit;
?>
