<?php
include "includes/header.php";
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
$uid = (int)$_SESSION['user_id'];
header("Location: profile.php?id=" . $uid);
exit;
