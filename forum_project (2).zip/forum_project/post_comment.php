
<?php
session_start();
include("db_connect.php");

if (!isset($_SESSION['user_id'])) {
    die("You must be logged in to comment.");
}

$topic_id = intval($_POST['topic_id']);
$comment_text = mysqli_real_escape_string($conn, $_POST['comment_text']);
$user_id = $_SESSION['user_id'];

$sql = "INSERT INTO comments (topic_id, user_id, comment_text, created_at)
        VALUES ($topic_id, $user_id, '$comment_text', NOW())";

if (mysqli_query($conn, $sql)) {
    include "log_activity.php";
    logActivity($conn, $_SESSION['user_id'], "commented", "Commented on Topic ID $topic_id");
    header("Location: view_topic.php?id=" . $topic_id);
    exit;
} else {
    echo "Error posting comment.";
}
?>
