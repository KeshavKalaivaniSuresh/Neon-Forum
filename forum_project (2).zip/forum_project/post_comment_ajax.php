<?php
// Returns JSON. Adds a comment and returns the inserted comment data so the frontend can append it.

header('Content-Type: application/json; charset=utf-8');

include("db_connect.php");

// Ensure session is available
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$response = ['success' => false];

if (!isset($_SESSION['user_id'])) {
    $response['error'] = 'not_logged_in';
    echo json_encode($response);
    exit;
}

$topic_id = isset($_POST['topic_id']) ? intval($_POST['topic_id']) : 0;
$comment_text = isset($_POST['comment_text']) ? trim($_POST['comment_text']) : '';

if ($topic_id <= 0 || $comment_text === '') {
    $response['error'] = 'invalid_input';
    echo json_encode($response);
    exit;
}

// Insert comment (prepared statement)
$stmt = mysqli_prepare($conn, "INSERT INTO comments (topic_id, user_id, comment_text, created_at) VALUES (?, ?, ?, NOW())");
$user_id = (int) $_SESSION['user_id'];
mysqli_stmt_bind_param($stmt, "iis", $topic_id, $user_id, $comment_text);

if (mysqli_stmt_execute($stmt)) {
    $comment_id = mysqli_insert_id($conn);

    // Get username for the user (or reuse session username)
    $username = $_SESSION['username'] ?? null;
    if (!$username) {
        $uStmt = mysqli_prepare($conn, "SELECT username FROM users WHERE id = ?");
        mysqli_stmt_bind_param($uStmt, "i", $user_id);
        mysqli_stmt_execute($uStmt);
        $uresult = mysqli_stmt_get_result($uStmt);
        $urow = mysqli_fetch_assoc($uresult);
        $username = $urow['username'] ?? 'User';
        mysqli_stmt_close($uStmt);
    }

    // Format created_at using MySQL's NOW(); fetch the row for consistency
    $cStmt = mysqli_prepare($conn, "SELECT created_at FROM comments WHERE id = ?");
    mysqli_stmt_bind_param($cStmt, "i", $comment_id);
    mysqli_stmt_execute($cStmt);
    $cres = mysqli_stmt_get_result($cStmt);
    $crow = mysqli_fetch_assoc($cres);
    $created_at = $crow['created_at'] ?? date('Y-m-d H:i:s');
    mysqli_stmt_close($cStmt);

    $response['success'] = true;
    $response['comment'] = [
        'id' => $comment_id,
        'topic_id' => $topic_id,
        'user_id' => $user_id,
        'username' => $username,
        'comment_text' => $comment_text,
        'created_at' => $created_at
    ];

    echo json_encode($response);
    exit;
} else {
    $response['error'] = 'db_error';
    echo json_encode($response);
    exit;
}
