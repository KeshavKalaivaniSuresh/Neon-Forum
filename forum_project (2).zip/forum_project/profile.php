<?php
include "includes/header.php";
include "db_connect.php";

$uid = intval($_GET['id'] ?? 0);
if ($uid <= 0) {
    echo "<div class='alert alert-warning'>Invalid user.</div>";
    include "footer.php";
    exit;
}

// fetch user
$stmt = mysqli_prepare($conn, "SELECT id, username, email, bio, profile_pic, created_at FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $uid);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $id, $username, $email, $bio, $profile_pic, $created_at);
if (!mysqli_stmt_fetch($stmt)) {
    mysqli_stmt_close($stmt);
    echo "<div class='alert alert-warning'>User not found.</div>";
    include "footer.php";
    exit;
}
mysqli_stmt_close($stmt);

// locate avatar path if exists
$avatarPath = ($profile_pic && file_exists(__DIR__ . "/uploads/" . $profile_pic)) ? "uploads/" . $profile_pic : null;
?>

<div class="row">
  <div class="col-md-4">
    <div class="card p-3 mb-3 text-center">
      <?php if ($avatarPath): ?>
        <img src="<?php echo htmlspecialchars($avatarPath); ?>" alt="avatar" class="img-fluid rounded mb-2" style="max-height:200px; object-fit:cover;">
      <?php else: ?>
        <div style="height:140px; width:140px; margin:0 auto;" class="profile-ghost mb-2"></div>
      <?php endif; ?>

      <h4 class="mt-2"><?php echo htmlspecialchars($username); ?></h4>
      <p class="small-muted mb-1">Member since <?php echo date("F j, Y", strtotime($created_at)); ?></p>
      <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $id): ?>
        <a class="btn btn-outline-light btn-sm mt-2" href="edit_profile.php">Edit Profile</a>
      <?php endif; ?>
    </div>
  </div>

  <div class="col-md-8">
    <div class="card p-3 mb-3">
      <h5 class="fw-semibold d-flex align-items-center justify-content-between">
        Bio
        <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1 && $_SESSION['user_id'] != $id): ?>
            <a href="suspend_user.php?id=<?php echo $id; ?>"
               class="btn btn-danger btn-sm"
               onclick="return confirm('Suspend this user? They will be unable to post, comment, or login.');">
               Suspend User
            </a>
        <?php endif; ?>
      </h5>
      <p class="small-muted"><?php echo nl2br(htmlspecialchars($bio ?? 'This user has not written a bio yet.')); ?></p>
    </div>

    <div class="card p-3">
      <h5 class="fw-semibold">Topics by <?php echo htmlspecialchars($username); ?></h5>
      <?php
        $tstmt = mysqli_prepare($conn, "SELECT id, title, created_at FROM topics WHERE user_id = ? ORDER BY id DESC LIMIT 50");
        mysqli_stmt_bind_param($tstmt, "i", $uid);
        mysqli_stmt_execute($tstmt);
        mysqli_stmt_bind_result($tstmt, $tid, $ttitle, $tcreated);
        while (mysqli_stmt_fetch($tstmt)):
      ?>
        <div class="mb-2">
          <a class="topic-title" href="view_topic.php?id=<?php echo $tid; ?>"><?php echo htmlspecialchars($ttitle); ?></a>
          <div class="small-muted"><?php echo date("M j, Y", strtotime($tcreated)); ?></div>
        </div>
      <?php endwhile; mysqli_stmt_close($tstmt); ?>
    </div>
  </div>
</div>

<?php include "footer.php"; ?>

