<?php
// DB connection
include("db_connect.php");

// Ensure a session exists before we set $_SESSION later
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$message = "";

// Handle form submission BEFORE output
if (isset($_POST['register'])) {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $raw_password = $_POST['password'] ?? '';

    // Basic validation
    if ($username === '' || $email === '' || $raw_password === '') {
        $message = "<div class='neon-alert neon-alert-glow'>Please fill all fields.</div>";
    } else {
        $password = password_hash($raw_password, PASSWORD_DEFAULT);

        // Check if username or email already exists
        $stmt = mysqli_prepare($conn, "SELECT id FROM users WHERE username=? OR email=?");
        mysqli_stmt_bind_param($stmt, "ss", $username, $email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);

        if (mysqli_stmt_num_rows($stmt) > 0) {
            $message = "<div class='neon-alert neon-alert-glow'>Username or Email Already Exists!</div>";
            mysqli_stmt_close($stmt);
        } else {
            mysqli_stmt_close($stmt);

            // Insert new user
            $stmt = mysqli_prepare($conn, "INSERT INTO users (username, email, password, role, created_at) VALUES (?, ?, ?, 'user', NOW())");
            mysqli_stmt_bind_param($stmt, "sss", $username, $email, $password);

            if (mysqli_stmt_execute($stmt)) {
                $user_id = mysqli_insert_id($conn);

                // Set session variables (session already started above)
                $_SESSION['user_id'] = $user_id;
                $_SESSION['username'] = $username;
                $_SESSION['role'] = 'user';

                mysqli_stmt_close($stmt);

                // Redirect to homepage
                header("Location: index.php");
                exit;
            } else {
                $message = "<div class='neon-alert neon-alert-glow'>Error: Could not register user.</div>";
                mysqli_stmt_close($stmt);
            }
        }
    }
}

// Now include header (will not re-start session because header uses guarded session_start)
include("includes/header.php");
?>

<!-- HTML form remains same -->
<div class="register-container d-flex justify-content-center align-items-start">
    <div class="card p-4 shadow-sm" style="border-radius: 12px; max-width: 400px; margin-top: 60px;">
        <h2 class="fw-bold neon-heading mb-4">Create an Account</h2>

        <?php echo $message; ?>

        <form method="POST" class="neon-form">
            <div class="mb-3">
                <label class="form-label fw-semibold">Enter Username</label>
                <input type="text" name="username" class="form-control" placeholder="Username" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Enter Email</label>
                <input type="email" name="email" class="form-control" placeholder="Email" required>
            </div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Enter Password</label>
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>

            <button type="submit" name="register" class="btn btn-primary w-100">Register</button>
        </form>
    </div>
</div>

<?php include("footer.php"); ?>





