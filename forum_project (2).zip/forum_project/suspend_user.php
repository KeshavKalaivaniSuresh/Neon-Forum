<?php
include "db_connect.php";
include "log_activity.php";

session_start();

// Only admin can suspend
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    die("Access denied.");
}

$uid = intval($_GET['id'] ?? 0);
if ($uid <= 0) {
    die("Invalid user ID.");
}

// Prevent admin from suspending themselves
if ($uid == $_SESSION['user_id']) {
    die("You cannot suspend yourself.");
}

// Check if user exists
$stmt = mysqli_prepare($conn, "SELECT username, suspended FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $uid);
mysqli_stmt_execute($stmt);
mysqli_stmt_bind_result($stmt, $username, $suspended);
if (!mysqli_stmt_fetch($stmt)) {
    mysqli_stmt_close($stmt);
    die("User not found.");
}
mysqli_stmt_close($stmt);

if ($suspended == 0) {
    // Suspend user
    $stmt = mysqli_prepare($conn, "UPDATE users SET suspended = 1 WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    // Delete comments first
    $stmt = mysqli_prepare($conn, "DELETE FROM comments WHERE user_id = ?");
    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    // Delete topics
    $stmt = mysqli_prepare($conn, "DELETE FROM topics WHERE user_id = ?");
    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    // Log suspension
    logActivity($conn, $uid, "suspend", "User suspended by admin");

    // Redirect to index
    header("Location: index.php");
    exit;

} else {
    die("User is already suspended.");
}

