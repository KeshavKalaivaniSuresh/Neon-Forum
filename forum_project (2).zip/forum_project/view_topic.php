
<?php
include("includes/header.php");
include("db_connect.php");

if (!isset($_GET['id'])) {
    echo "<div class='alert alert-danger'>Invalid topic ID.</div>";
    include("footer.php");
    exit;
}

$topic_id = intval($_GET['id']);

// Fetch topic (with author username)
$topic_sql = "SELECT topics.*, users.username 
              FROM topics 
              JOIN users ON topics.user_id = users.id
              WHERE topics.id = $topic_id";
$topic_result = mysqli_query($conn, $topic_sql);

if (!$topic_result || mysqli_num_rows($topic_result) == 0) {
    echo "<div class='alert alert-danger'>Topic not found.</div>";
    include("footer.php");
    exit;
}

$topic = mysqli_fetch_assoc($topic_result);
?>

<h2 class="fw-bold neon-heading mb-2"><?php echo htmlspecialchars($topic['title']); ?></h2>
<p class="post-meta mb-4">
    Posted by 
    <b>
        <a href="profile.php?id=<?php echo intval($topic['user_id']); ?>" class="text-decoration-none neon-link">
            <?php echo htmlspecialchars($topic['username']); ?>
        </a>
    </b>
    • <?php echo date("F j, Y g:i A", strtotime($topic['created_at'])); ?>
</p>

<div class="card card-post p-4 mb-4 shadow-sm topic-content">
    <p><?php echo nl2br(htmlspecialchars($topic['content'])); ?></p>
</div>

<?php
// show Edit/Delete to owner OR admin can delete
if (isset($_SESSION['user_id']) && ($_SESSION['user_id'] == $topic['user_id'] || (isset($_SESSION['is_admin']) && $_SESSION['is_admin']))): ?>
    <div class="mb-4">
        <?php if ($_SESSION['user_id'] == $topic['user_id']): ?>
            <a href="edit_topic.php?id=<?php echo $topic_id; ?>" class="btn btn-warning btn-sm">Edit Topic</a>
        <?php endif; ?>

        <a href="delete_topic.php?id=<?php echo $topic_id; ?>" 
           class="btn btn-danger btn-sm"
           onclick="return confirm('<?php echo (isset($_SESSION['is_admin']) && $_SESSION['is_admin']) ? 'Admin: delete this topic?' : 'Are you sure you want to delete this topic?'; ?>');">
           Delete Topic
        </a>
    </div>
<?php endif; ?>

<h3 class="fw-bold neon-heading mb-3">Discussion</h3>

<?php
$comment_sql = "SELECT comments.*, users.username 
                FROM comments 
                JOIN users ON comments.user_id = users.id 
                WHERE topic_id = $topic_id
                ORDER BY comments.created_at ASC";
$comment_result = mysqli_query($conn, $comment_sql);

if (mysqli_num_rows($comment_result) > 0):
    while ($comment = mysqli_fetch_assoc($comment_result)):
?>
<div class="comment comment-card p-3 mb-3 shadow-sm d-flex justify-content-between">
    <div style="flex:1;">
        <p class="mb-1">
            <span class="badge badge-neon"><?php echo htmlspecialchars($comment['username']); ?></span>
        </p>
        <p class="comment-text mb-1"><?php echo nl2br(htmlspecialchars($comment['comment_text'])); ?></p>
        <small class="comment-date"><?php echo date("F j, Y g:i A", strtotime($comment['created_at'])); ?></small>
    </div>

    <div class="ms-3" style="min-width:80px; text-align:right;">
        <?php
        // Show delete for comment owner or admin
        if (isset($_SESSION['user_id']) && ($_SESSION['user_id'] == $comment['user_id'] || (isset($_SESSION['is_admin']) && $_SESSION['is_admin']))): ?>
            <a class="btn btn-sm btn-danger" href="delete_comment.php?id=<?php echo intval($comment['id']); ?>&topic_id=<?php echo $topic_id; ?>" onclick="return confirm('Delete this comment?');">Delete</a>
        <?php endif; ?>
    </div>
</div>
<?php
    endwhile;
else:
?>
<p>No comments yet. Be the first to reply!</p>
<?php endif; ?>

<?php if (isset($_SESSION['user_id'])): ?>
<div class="card p-3 mt-4 shadow-sm" style="border-radius: 12px; max-width: 600px;">
    <form method="POST" action="post_comment.php">
        <input type="hidden" name="topic_id" value="<?php echo $topic_id; ?>">
        <label class="form-label fw-semibold">Your Comment</label>
        <textarea name="comment_text" rows="3" class="form-control neon-input mb-3" required></textarea>
        <button type="submit" class="btn btn-primary neon-btn">Post Comment</button>
    </form>
</div>
<?php else: ?>
<p class="mt-3"><a href="login.php">Login</a> to comment.</p>
<?php endif; ?>

<!-- AJAX live comment submit — add directly BEFORE <?php include("footer.php"); ?> -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const commentForm = document.querySelector('form[action="post_comment.php"]');
    if (!commentForm) return; // if form not found, do nothing

    commentForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const formData = new FormData(commentForm);
        const topicId = formData.get('topic_id');
        const commentText = formData.get('comment_text').trim();

        if (!commentText) {
            alert('Please write a comment first.');
            return;
        }

        const submitBtn = commentForm.querySelector('button[type="submit"]');
        if (submitBtn) submitBtn.disabled = true;

        fetch('post_comment_ajax.php', {
            method: 'POST',
            body: formData,
            credentials: 'same-origin'
        })
        .then(res => res.json())
        .then(data => {
            if (submitBtn) submitBtn.disabled = false;

            if (!data || !data.success) {
                if (data && data.error === 'not_logged_in') {
                    alert('You must be logged in to comment.');
                    window.location.href = 'login.php';
                    return;
                }
                alert('Error posting comment. Please try again.');
                return;
            }

            const c = data.comment;
            const container = document.createElement('div');
            container.className = 'comment comment-card p-3 mb-3 shadow-sm d-flex justify-content-between';
            container.innerHTML = `
                <div style="flex:1;">
                    <p class="mb-1"><span class="badge badge-neon">${escapeHtml(c.username)}</span></p>
                    <p class="comment-text mb-1">${nl2br(escapeHtml(c.comment_text))}</p>
                    <small class="comment-date">${formatDateTime(c.created_at)}</small>
                </div>
                <div class="ms-3" style="min-width:80px; text-align:right;">
                    <a class="btn btn-sm btn-danger" href="delete_comment.php?id=${c.id}&topic_id=${c.topic_id}" onclick="return confirm('Delete this comment?');">Delete</a>
                </div>
            `;

            const formCard = commentForm.closest('.card') || commentForm.parentElement;
            formCard.parentNode.insertBefore(container, formCard);
            const ta = commentForm.querySelector('textarea[name="comment_text"]');
            if (ta) ta.value = '';
            container.scrollIntoView({ behavior: 'smooth', block: 'center' });
        })
        .catch(err => {
            if (submitBtn) submitBtn.disabled = false;
            console.error(err);
            alert('Network error while posting comment.');
        });
    });

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function nl2br(str) {
        return str.replace(/\r\n|\n\r|\r|\n/g, '<br>');
    }

    function formatDateTime(mysqlDatetime) {
        const d = new Date(mysqlDatetime.replace(' ', 'T'));
        if (!isNaN(d.getTime())) {
            const options = { month: 'long', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' };
            return d.toLocaleString(undefined, options);
        }
        return mysqlDatetime;
    }
});
</script>
<!-- End AJAX block -->

<?php include("footer.php"); ?>

<style>
.neon-heading { color: #00ffff; text-shadow: 0 0 5px #00ffff, 0 0 10px #7c4dff, 0 0 15px #00ffff; }
.card-post, .topic-content { background-color: #1b1f2a; border:1px solid #00ffff55; box-shadow:0 0 8px #00ffff33; }
.card-post:hover, .topic-content:hover { box-shadow:0 0 15px #00ffff55,0 0 25px #7c4dff33; transition:0.3s; }
.comment-card { background-color: #1b1f2a; padding:10px; border-radius:10px; margin-bottom:10px; color:#f0f4ff; border:1px solid #ff00ff55; box-shadow:0 0 5px #ff00ff33,0 0 10px #ff00ff22; }
.comment-card:hover { box-shadow:0 0 10px #ff00ff55,0 0 20px #ff00ff33; transition:0.3s; }
textarea.neon-input { background-color: #1b1f2a; color:#f0f4ff; border:1px solid #00ffff; box-shadow:0 0 8px #00ffff33; border-radius:8px; transition:0.3s; }
textarea.neon-input:focus { outline:none; border-color:#00ffff; box-shadow:0 0 12px #00ffff55; }
button.neon-btn { background-color:#00ffff; color:#000; border:none; box-shadow:0 0 8px #00ffff33; transition:0.3s; }
button.neon-btn:hover { box-shadow:0 0 15px #00ffff55; }
body { font-family:'Poppins', sans-serif; }
.badge-neon { background: linear-gradient(90deg,#7c4dff,#00e5ff); color:#00101a; font-weight:700; text-shadow:0 0 5px #fff88; }
</style>



